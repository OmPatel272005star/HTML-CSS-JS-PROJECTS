//variable
let btn=document.querySelector('.btn');
let quote=document.querySelector('.quote');
let person=document.querySelector('.writer');

const quotes=[{
quote:`"The only thing we have to fear is fear itself."`,
person:` Franklin D. Roosevelt`
},{
    quote:`"In the end, we will remember not the words of our enemies, but the silence of our friends."`,
    person:` Martin Luther King Jr.`
 },{
        quote:`"The greatest glory in living lies not in never falling, but in rising every time we fall."`,
        person:` Nelson Mandela`
 },{
    quote:`"Leadership is not about being in charge. It is about taking care of those in your charge."`,
    person:` Simon Sinek`
},{
    quote:`"If you want to go fast, go alone. If you want to go far, go together."`,
    person:` African Proverb`
},{
    quote:`"The quality of a leader is reflected in the standards they set for themselves."`,
    person:` ohn F. Kennedy`
},{
    quote:`"Leadership is not wielding authority—it's empowering people."  `,
    person:` Becky Brodin`
},{
    quote:`"Arise, awake, and stop not until the goal is achieved."`,
    person:` Swami Vivekananda`
 },{
    quote:`"Take to the path of dharma - the path of truth and justice. Don't misuse your valour."`,
    person:` Sardar Vallabhbhai Patel`
},{
    quote:`"Give me blood, and I shall give you freedom."`,
    person:` Subhas Chandra Bose`
}
];

btn.addEventListener('click',function(){
  let random=Math.floor(Math.random()*quotes.length);
  quote.innerText=quotes[random].quote;
  person.innerText=quotes[random].person;
})
//ypu can't use Math.round,Math.ceil bcz when random generate 0.9 then this two function change it to 1*10=10 & quotes[10] is not in the length of this array so it will give runtime error
//(2) Separate arrays for quotes and authors
/*const quotes = [
    "The only thing we have to fear is fear itself.",
    "In the end, we will remember not the words of our enemies, but the silence of our friends.",
    "The greatest glory in living lies not in never falling, but in rising every time we fall.",
    // ... other quotes ...
  ];
  
  const authors = [
    "Franklin D. Roosevelt",
    "Martin Luther King Jr.",
    "Nelson Mandela",
    // ... other authors ...
  ];
  
  let btn = document.querySelector('.btn');
  let quote = document.querySelector('.quote');
  let person = document.querySelector('.writer');
  
  btn.addEventListener('click', function () {
    let random = Math.floor(Math.random() * quotes.length);
  
    // Update the quote and author
    quote.innerText = quotes[random];
    person.innerText = authors[random];
  });
  */